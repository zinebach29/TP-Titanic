
#' Calculer le taux de survie des passagers
#'
#' Cette fonction calcule le taux de survie des passagers
#' selon une variable choisie (sexe, classe, etc.).
#'
#'@author Zineb
#' @param data Jeu de données contenant les passagers.
#' @param variable colonne donnee
#'
#' @return Un tableau contenant les modalités et les taux de survie.
#' @export

taux_survie <- function(data, variable) {
  
  if (!variable %in% names(data)) {
    stop("La variable demandee n'existe pas.")
  }
  
  if (!"survived" %in% names(data)) {
    stop("La variable survived est absente.")
  }
  
  groupes <- split(data$survived, data[[variable]])
  
  resultat <- data.frame(
    modalite = names(groupes),
    taux_survie = sapply(groupes, function(x) {
      mean(x == "yes", na.rm = TRUE) * 100
    })
  )
  
  return(resultat)
}

